package com.nduchane.locationsaver

import android.location.Geocoder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.nduchane.locationsaver.databinding.ActivityShowSavedLocationListBinding

class ShowSavedLocationList : AppCompatActivity() {
    lateinit var binding : ActivityShowSavedLocationListBinding
    lateinit var locationsList : TextView
    lateinit var geocoder : Geocoder

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityShowSavedLocationListBinding.inflate(layoutInflater)
        setContentView(binding.root)
//initialize
        locationsList = binding.locationsListItemsTextview
        geocoder = Geocoder(this)
        var finalString = ""
// get all locations
        for(location in Constants.LOCATION_LIST){
            println(location)
            finalString = finalString + "Longitude: " + location.longitude.toString() + "\n" + "Latitude: " + location.latitude.toString() + "\n\n"
        }
// set all to the view
        locationsList.text = finalString
    }
}


