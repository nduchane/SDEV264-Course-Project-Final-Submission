package com.nduchane.locationsaver

import android.location.Location

object Constants {
    val PERMISSION_FINE_LOCATION : Int = 321
    var LOCATION_LIST = ArrayList<Location>()
}